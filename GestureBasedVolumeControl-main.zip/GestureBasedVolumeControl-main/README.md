# GestureBasedVolumeControl
This is a project that shows how to create your own gesture based volume controller for your PC using Python.


To run this use 

git clone https://github.com/CodegnanITSolutions/GestureBasedVolumeControl.git (or) can also download the zip file.

To install required packages use the below lines of code from CMD

pip install opencv-python

pip install mdeiapipe

pip install math

pip install ctypes

pip install pycaw

pip install numpy

now open CMD in the directory where you cloned it and run

python inst2.py

#HappyCoding
